 Remove this package as  pip3 alternative.
/usr/sbin/alternatives --remove pip3 /usr/bin/pip3.11

