# Install this package as a pip3 alternative.
/usr/sbin/alternatives --install /usr/bin/pip3 pip3  /usr/bin/pip3.12 312

