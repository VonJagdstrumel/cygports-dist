# Remove this package as a pip3 alternative.
/usr/sbin/alternatives --remove pip3 /usr/bin/pip3.13

