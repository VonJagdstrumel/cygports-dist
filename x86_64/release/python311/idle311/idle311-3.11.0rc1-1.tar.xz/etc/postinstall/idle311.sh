# Install this package as a idle alternative.
# PYTHON_VERSION=3.11
# PYTHON_PRIORITY=311
/usr/sbin/alternatives --install /usr/bin/idle3 idle3 /usr/bin/idle3.11 311

