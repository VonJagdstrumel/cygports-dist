# Remove this package as a python alternative.
/usr/sbin/alternatives --remove 2to3 /usr/bin/2to3-3.11
/usr/sbin/alternatives --remove python3-config /usr/bin/python3.11-config

