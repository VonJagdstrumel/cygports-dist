# Install this package as a python devel alternative.
# PYTHON_VERSION=3.11
# PYTHON_PRIORITY=311
/usr/sbin/alternatives --install /usr/bin/2to3 2to3 /usr/bin/2to3-3.11 311
/usr/sbin/alternatives --install /usr/bin/python3-config python3-config /usr/bin/python3.11-config 311

