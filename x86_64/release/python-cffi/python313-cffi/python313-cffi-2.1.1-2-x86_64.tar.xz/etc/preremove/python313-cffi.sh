# Remove this package as a f2py alternative.
/usr/sbin/alternatives --remove f2py /usr/bin/f2py3.13

