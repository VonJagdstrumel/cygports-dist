# Install this package as a cffi-gen-src alternative.
/usr/sbin/alternatives --install /usr/bin/cffi-gen-src cffi-gen-src /usr/bin/cffi-gen-src3.12 312

