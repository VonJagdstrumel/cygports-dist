# Remove this package as a python alternative.
/usr/sbin/alternatives --remove python3-config /usr/bin/python3.13-config

