# Install this package as a python devel alternative.
# PYTHON_VERSION=3.13
# PYTHON_PRIORITY=313
/usr/sbin/alternatives --install /usr/bin/python3-config python3-config /usr/bin/python3.13-config 313

