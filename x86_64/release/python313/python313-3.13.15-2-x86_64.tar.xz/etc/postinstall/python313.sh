# Install this package as a python alternative.
# PYTHON_VERSION=3.13
# PYTHON_PRIORITY=313
/usr/sbin/alternatives --install /usr/bin/python python /usr/bin/python3.13 313
/usr/sbin/alternatives --install /usr/bin/python3 python3 /usr/bin/python3.13 313
/usr/sbin/alternatives --install /usr/bin/pydoc3 pydoc3 /usr/bin/pydoc3.13 313

rm -f /usr/share/icons/hicolor/icon-theme.cache
