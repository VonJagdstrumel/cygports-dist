# Install this package as a idle alternative.
# PYTHON_VERSION=3.13
# PYTHON_PRIORITY=313
/usr/sbin/alternatives --install /usr/bin/idle3 idle3 /usr/bin/idle3.13 313

