# Remove this package as a python alternative.
/usr/sbin/alternatives --remove idle3 /usr/bin/idle3.13

