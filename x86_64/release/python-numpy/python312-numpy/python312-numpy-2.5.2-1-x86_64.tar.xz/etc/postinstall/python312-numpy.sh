# Install this package as a f2py alternative.
/usr/sbin/alternatives --install /usr/bin/f2py f2py /usr/bin/f2py3.12 312
/usr/sbin/alternatives --install /usr/bin/numpy-config numpy-config /usr/bin/numpy-config3.12 312

