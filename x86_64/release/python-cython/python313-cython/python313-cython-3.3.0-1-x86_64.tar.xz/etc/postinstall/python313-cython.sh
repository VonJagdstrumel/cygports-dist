# Install this package as a cython alternative.
/usr/sbin/alternatives --install /usr/bin/cygdb cygdb /usr/bin/cygdb3.13 313
/usr/sbin/alternatives --install /usr/bin/cython cython /usr/bin/cython3.13 313
/usr/sbin/alternatives --install /usr/bin/cythonize cythonize /usr/bin/cythonize3.13 313

