# Remove this package as a cython alternative.
/usr/sbin/alternatives --remove cygdb /usr/bin/cygdb3.12
/usr/sbin/alternatives --remove cython /usr/bin/cython3.12
/usr/sbin/alternatives --remove cythonize /usr/bin/cythonize3.12

